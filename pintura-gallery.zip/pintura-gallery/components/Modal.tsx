"use client";

import { useEffect, useRef } from "react";
import type { Painting } from "@/data/paintings";

type ModalProps = {
  painting: Painting;
  onClose: () => void;
};

export default function Modal({ painting, onClose }: ModalProps) {
  const dialogRef = useRef<HTMLDivElement>(null);
  const closeBtnRef = useRef<HTMLButtonElement>(null);

  // Fecha com a tecla ESC (comportamento pensado para desktop)
  useEffect(() => {
    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") {
        onClose();
      }
    }
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [onClose]);

  // Trava o scroll do body enquanto o modal está aberto
  useEffect(() => {
    const original = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeBtnRef.current?.focus();
    return () => {
      document.body.style.overflow = original;
    };
  }, []);

  // Fecha ao clicar fora da imagem/card (funciona em desktop e mobile)
  function handleBackdropClick(event: React.MouseEvent<HTMLDivElement>) {
    if (event.target === event.currentTarget) {
      onClose();
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/90 backdrop-blur-sm animate-fadeIn p-4 sm:p-8"
      onClick={handleBackdropClick}
      role="presentation"
    >
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
        className="relative w-full max-w-4xl max-h-[92vh] overflow-y-auto rounded-sm border border-moss-700/60 bg-ink-900 shadow-[0_0_0_1px_rgba(46,125,83,0.15),0_30px_80px_-20px_rgba(0,0,0,0.8)] animate-riseIn"
      >
        {/* Botão fechar — sempre visível, essencial no mobile onde não há ESC */}
        <button
          ref={closeBtnRef}
          onClick={onClose}
          aria-label="Fechar"
          className="absolute right-3 top-3 z-10 flex h-10 w-10 items-center justify-center rounded-full border border-moss-500/40 bg-ink-950/80 text-linen-100 transition-colors hover:border-moss-400 hover:text-moss-300 sm:right-4 sm:top-4"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.5"
            className="h-5 w-5"
          >
            <path strokeLinecap="round" d="M6 6l12 12M18 6L6 18" />
          </svg>
        </button>

        <div className="flex justify-center bg-ink-950/40 px-3 py-6 sm:px-8 sm:py-10">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={painting.src}
            alt={`${painting.title}, de ${painting.artist}`}
            className="max-h-[62vh] w-auto rounded-[1px] object-contain shadow-[0_20px_60px_-15px_rgba(0,0,0,0.9)]"
          />
        </div>

        <div className="border-t border-moss-700/30 px-5 py-5 sm:px-8 sm:py-7">
          <p className="font-display text-xs uppercase tracking-[0.2em] text-moss-400">
            {painting.year}
          </p>
          <h2
            id="modal-title"
            className="mt-1 font-display text-2xl italic text-linen-100 sm:text-3xl"
          >
            {painting.title}
          </h2>
          <p className="mt-1 text-sm text-linen-300 sm:text-base">
            {painting.artist}
          </p>
          <p className="mt-3 max-w-prose text-sm leading-relaxed text-linen-500">
            {painting.note}
          </p>
        </div>
      </div>
    </div>
  );
}
