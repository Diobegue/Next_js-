"use client";

import { useState } from "react";
import type { Painting } from "@/data/paintings";
import Modal from "./Modal";

const orientationSpan: Record<Painting["orientation"], string> = {
  portrait: "row-span-2",
  landscape: "sm:col-span-2",
  square: "",
};

export default function Gallery({ paintings }: { paintings: Painting[] }) {
  const [selected, setSelected] = useState<Painting | null>(null);

  return (
    <>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 sm:gap-5 lg:grid-cols-3 lg:gap-6">
        {paintings.map((painting, index) => (
          <button
            key={painting.id}
            onClick={() => setSelected(painting)}
            className={`group relative overflow-hidden rounded-sm border border-moss-700/25 bg-ink-900 text-left transition-all duration-300 hover:border-moss-500/60 focus-visible:border-moss-400 ${orientationSpan[painting.orientation]}`}
            style={{ animationDelay: `${index * 40}ms` }}
          >
            <div className="relative aspect-[4/5] w-full overflow-hidden bg-ink-950">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={painting.src}
                alt={`${painting.title}, de ${painting.artist}`}
                loading="lazy"
                className="h-full w-full object-cover opacity-90 grayscale-[15%] transition-all duration-500 ease-out group-hover:scale-105 group-hover:opacity-100 group-hover:grayscale-0"
              />
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink-950/95 via-ink-950/10 to-transparent opacity-70 transition-opacity duration-300 group-hover:opacity-90" />
              <div className="absolute inset-x-0 bottom-0 translate-y-1 p-4 transition-transform duration-300 group-hover:translate-y-0 sm:p-5">
                <p className="font-display text-[11px] uppercase tracking-[0.2em] text-moss-400">
                  {painting.year}
                </p>
                <h3 className="mt-1 font-display text-lg italic leading-snug text-linen-100 sm:text-xl">
                  {painting.title}
                </h3>
                <p className="text-xs text-linen-300 sm:text-sm">
                  {painting.artist}
                </p>
              </div>
            </div>
          </button>
        ))}
      </div>

      {selected && (
        <Modal painting={selected} onClose={() => setSelected(null)} />
      )}
    </>
  );
}
