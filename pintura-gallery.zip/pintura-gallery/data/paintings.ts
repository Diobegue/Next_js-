export type Painting = {
  id: string;
  title: string;
  artist: string;
  year: string;
  src: string;
  orientation: "portrait" | "landscape" | "square";
  note: string;
};

// Imagens hospedadas externamente no Wikimedia Commons (domínio público).
export const paintings: Painting[] = [
  {
    id: "noite-estrelada",
    title: "A Noite Estrelada",
    artist: "Vincent van Gogh",
    year: "1889",
    src: "https://upload.wikimedia.org/wikipedia/commons/e/ea/Van_Gogh_-_Starry_Night_-_Google_Art_Project.jpg",
    orientation: "landscape",
    note: "Óleo sobre tela, pintado em Saint-Rémy-de-Provence.",
  },
  {
    id: "o-beijo",
    title: "O Beijo",
    artist: "Gustav Klimt",
    year: "1908",
    src: "https://upload.wikimedia.org/wikipedia/commons/4/40/The_Kiss_-_Gustav_Klimt_-_Google_Cultural_Institute.jpg",
    orientation: "square",
    note: "Fase dourada do artista, Belvedere, Viena.",
  },
  {
    id: "grande-onda",
    title: "A Grande Onda de Kanagawa",
    artist: "Katsushika Hokusai",
    year: "1831",
    src: "https://upload.wikimedia.org/wikipedia/commons/a/a5/Tsunami_by_hokusai_19th_century.jpg",
    orientation: "landscape",
    note: "Xilogravura da série Trinta e Seis Vistas do Monte Fuji.",
  },
  {
    id: "monalisa",
    title: "Mona Lisa",
    artist: "Leonardo da Vinci",
    year: "c. 1503",
    src: "https://upload.wikimedia.org/wikipedia/commons/6/6a/Mona_Lisa.jpg",
    orientation: "portrait",
    note: "Museu do Louvre, Paris.",
  },
  {
    id: "o-grito",
    title: "O Grito",
    artist: "Edvard Munch",
    year: "1893",
    src: "https://upload.wikimedia.org/wikipedia/commons/f/f4/The_Scream.jpg",
    orientation: "landscape",
    note: "Ícone do Expressionismo, Galeria Nacional da Noruega.",
  },
  {
    id: "nascimento-de-venus",
    title: "O Nascimento de Vênus",
    artist: "Sandro Botticelli",
    year: "c. 1485",
    src: "https://upload.wikimedia.org/wikipedia/commons/0/0b/Sandro_Botticelli_-_La_nascita_di_Venere_-_Google_Art_Project_-_edited.jpg",
    orientation: "landscape",
    note: "Têmpera sobre tela, Galeria Uffizi, Florença.",
  },
  {
    id: "moca-com-brinco-de-perola",
    title: "Moça com Brinco de Pérola",
    artist: "Johannes Vermeer",
    year: "1665",
    src: "https://upload.wikimedia.org/wikipedia/commons/0/0f/1665_Girl_with_a_Pearl_Earring.jpg",
    orientation: "portrait",
    note: "Conhecida como a 'Mona Lisa do Norte'.",
  },
  {
    id: "ninfeias",
    title: "Ninfeias",
    artist: "Claude Monet",
    year: "1906",
    src: "https://upload.wikimedia.org/wikipedia/commons/e/e0/Claude_Monet_038.jpg",
    orientation: "square",
    note: "Parte da série pintada no jardim de Giverny.",
  },
  {
    id: "composicao-viii",
    title: "Composição VIII",
    artist: "Wassily Kandinsky",
    year: "1923",
    src: "https://upload.wikimedia.org/wikipedia/commons/9/94/Vassily_Kandinsky%2C_1923_-_Composition_8%2C_huile_sur_toile%2C_140_cm_x_201_cm%2C_Mus%C3%A9e_Guggenheim%2C_New_York.jpg",
    orientation: "landscape",
    note: "Museu Guggenheim, Nova York.",
  },
  {
    id: "quarto-em-arles",
    title: "O Quarto em Arles",
    artist: "Vincent van Gogh",
    year: "1888",
    src: "https://upload.wikimedia.org/wikipedia/commons/2/28/Vincent_van_Gogh_-_De_slaapkamer_-_Google_Art_Project.jpg",
    orientation: "landscape",
    note: "Uma das três versões pintadas pelo artista.",
  },
  {
    id: "criacao-de-adao",
    title: "A Criação de Adão",
    artist: "Michelangelo",
    year: "c. 1512",
    src: "https://upload.wikimedia.org/wikipedia/commons/6/66/Creaci%C3%B3n_de_Ad%C3%A1n_%28Miguel_%C3%81ngel%29.jpg",
    orientation: "landscape",
    note: "Afresco no teto da Capela Sistina, Vaticano.",
  },
  {
    id: "guernica",
    title: "Guernica",
    artist: "Pablo Picasso",
    year: "1937",
    src: "https://upload.wikimedia.org/wikipedia/en/7/74/PicassoGuernica.jpg",
    orientation: "landscape",
    note: "Resposta ao bombardeio da cidade basca, Museu Reina Sofía.",
  },
];
