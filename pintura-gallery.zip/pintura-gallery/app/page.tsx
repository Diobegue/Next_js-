import Gallery from "@/components/Gallery";
import { paintings } from "@/data/paintings";

export default function Home() {
  return (
    <main className="mx-auto max-w-6xl px-5 pb-24 pt-12 sm:px-8 sm:pt-20 lg:px-10">
      <header className="mb-14 max-w-2xl sm:mb-20">
        <p className="font-display text-xs uppercase tracking-[0.3em] text-moss-400">
          Coleção permanente
        </p>
        <h1 className="mt-4 font-display text-4xl italic leading-[1.1] text-linen-100 sm:text-5xl lg:text-6xl">
          Galeria Verdiana
        </h1>
        <p className="mt-5 max-w-md text-sm leading-relaxed text-linen-500 sm:text-base">
          Doze obras que atravessaram séculos de pintura, reunidas aqui sob
          uma única luz: o verde-musgo contra o breu. Toque em qualquer tela
          para observá-la de perto.
        </p>
      </header>

      <Gallery paintings={paintings} />

      <footer className="mt-24 border-t border-moss-700/20 pt-6 text-xs text-linen-500">
        <p>
          Imagens de domínio público, hospedadas externamente via Wikimedia
          Commons.
        </p>
      </footer>
    </main>
  );
}
